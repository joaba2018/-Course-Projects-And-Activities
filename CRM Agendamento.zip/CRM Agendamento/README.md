# entra21-bootstrap
Projeto base para o trabalho da mostra de talentos
